#define __IOTK_VERSION "1.1.0development"
#define __IOTK_VERSION_MAJOR 1
#define __IOTK_VERSION_MINOR 1
#define __IOTK_VERSION_PATCH 0
#define __IOTK_VERSION_EXTRA "development"
